TODO
====

* Improve and organize the docs, add more examples
* Upgrade algorithm to Unicode 7.0.0
* Fix failing explicit test (commented)
* Arabic shaping
